<?php
// Initialize result variable
$result = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input from form
    $text = $_POST['user_input'] ?? '';
    
    // Calculate string properties
    $length = strlen($text);              // Number of characters
    $words = str_word_count($text);       // Number of words
    $reverse = strrev($text);             // Reversed string

    // Build result output
    $result = "
        <h3>Analysis Result</h3>
        <ul>
            <li>Input text: <b>$text</b></li>
            <li>Number of characters: $length</li>
            <li>Number of words: $words</li>
            <li>Reversed: $reverse</li>
        </ul>
    ";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP Docker Web App</title>
</head>
<body>
    <h1>PHP String Analyzer (Docker Deployment)</h1>
    <form method="POST">
        <label for="user_input">Enter a sentence:</label><br><br>
        <input type="text" id="user_input" name="user_input" required>
        <button type="submit">Analyze</button>
    </form>
    <hr>
    <div>
        <?php echo $result; ?>
    </div>
</body>
</html>
